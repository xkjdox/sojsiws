#!/usr/bin/env python3
# it's ok to use /usr/bin/env

import sys
print(sys.argv)
print("hello world")
