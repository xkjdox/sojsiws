# doesn't require a shebang
# bash in PATH will be called

echo "\$@ is $@"
echo "command line: $0 $*"
echo "\$BASH is $BASH"
echo "hello world"
