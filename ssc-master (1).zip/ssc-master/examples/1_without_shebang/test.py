# doesn't require a shebang
# python in PATH will be called

import sys
print(sys.argv)
print("hello world")
