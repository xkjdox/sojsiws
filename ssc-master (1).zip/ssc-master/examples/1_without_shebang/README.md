# Compile a script without shebang

The script must have a supported file extension.

```bash
../../ssc test.sh binary
../../ssc test.bash binary
../../ssc test.py binary
```
