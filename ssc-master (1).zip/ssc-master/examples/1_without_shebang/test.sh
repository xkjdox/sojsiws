# doesn't require a shebang
# default sh will be called

echo "\$@ is $@"
echo "command line: $0 $*"
echo "\$SSC_INTERPRETER_PATH is $SSC_INTERPRETER_PATH"
echo "\$SSC_EXECUTABLE_PATH is $SSC_EXECUTABLE_PATH"
echo "\$SSC_ARGV0 is $SSC_ARGV0"
echo "hello world"
