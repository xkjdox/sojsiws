#!./bash-static

echo "\$@ is $@"
echo "hello world"
